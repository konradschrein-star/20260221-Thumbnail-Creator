"""
================================================================================
AI Thumbnail Rendering Farm - Next.js Dashboard
================================================================================
Main dashboard for Virtual Assistants to monitor and manage thumbnail generation.
Works with both local development and Vercel deployment.
================================================================================
"""

"use client";

import React, { useState, useEffect, useCallback, useRef } from "react";
import Head from "next/head";

// =============================================================================
// API URL Detection (works with both local and Vercel)
// =============================================================================

const getApiBaseUrl = () => {
  // In browser, check if we're on Vercel (same origin for API)
  if (typeof window !== 'undefined') {
    // If API is at same origin (Vercel), use relative URL
    if (window.location.hostname.includes('vercel.app')) {
      return '';
    }
  }
  // Otherwise use environment variable or default to localhost
  return process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
};

const API_BASE_URL = getApiBaseUrl();

// =============================================================================
// Type Definitions
// =============================================================================

interface ThumbnailVariant {
  variant_id: string;
  image_url: string;
  metadata?: {
    prompt?: string;
    style?: string;
  };
}

interface JobStatus {
  job_id: string;
  status: "pending" | "processing" | "completed" | "failed" | "unknown";
  progress: number;
  message?: string;
  variants?: ThumbnailVariant[];
  error?: string;
  timestamp?: string;
}

interface GenerationRequest {
  channel_id: string;
  video_title: string;
  video_description?: string;
  reference_thumbnail_url?: string;
  num_variants: number;
}

// =============================================================================
// API Client
// =============================================================================

async function submitGenerationRequest(
  request: GenerationRequest
): Promise<{ job_id: string; estimated_seconds: number }> {
  const response = await fetch(`${API_BASE_URL}/api/v1/thumbnails/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to submit generation request");
  }

  return response.json();
}

async function regenerateThumbnails(
  jobId: string
): Promise<{ job_id: string; estimated_seconds: number }> {
  const response = await fetch(
    `${API_BASE_URL}/api/v1/thumbnails/regenerate/${jobId}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
    }
  );

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to regenerate thumbnails");
  }

  return response.json();
}

async function fetchJobStatus(jobId: string): Promise<JobStatus> {
  const response = await fetch(`${API_BASE_URL}/api/v1/thumbnails/status/${jobId}`);
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to fetch job status");
  }
  
  return response.json();
}

// =============================================================================
// SSE Hook
// =============================================================================

function useJobStatusStream(jobId: string | null) {
  const [status, setStatus] = useState<JobStatus | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const eventSourceRef = useRef<EventSource | null>(null);
  const pollIntervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (!jobId) {
      setStatus(null);
      setIsConnected(false);
      setError(null);
      return;
    }

    // Close existing connection
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }
    
    if (pollIntervalRef.current) {
      clearInterval(pollIntervalRef.current);
    }

    // Try SSE first, fall back to polling
    const useSSE = typeof window !== 'undefined' && !window.location.hostname.includes('vercel.app');
    
    if (useSSE) {
      // Use SSE for local development
      const eventSource = new EventSource(
        `${API_BASE_URL}/api/v1/thumbnails/stream/${jobId}`
      );
      eventSourceRef.current = eventSource;

      eventSource.onopen = () => {
        setIsConnected(true);
        setError(null);
      };

      eventSource.addEventListener("status", (event: MessageEvent) => {
        try {
          const data = JSON.parse(event.data);
          setStatus((prev) => ({
            ...prev,
            ...data,
            job_id: jobId,
          }));
        } catch (e) {
          console.error("Failed to parse status event:", e);
        }
      });

      eventSource.addEventListener("complete", (event: MessageEvent) => {
        try {
          const data = JSON.parse(event.data);
          setStatus((prev) => ({
            ...prev,
            status: data.final_status,
            job_id: jobId,
          }));
        } catch (e) {
          console.error("Failed to parse complete event:", e);
        }
        eventSource.close();
        setIsConnected(false);
      });

      eventSource.addEventListener("error", (event: MessageEvent) => {
        try {
          const data = JSON.parse(event.data);
          setError(data.error || "Connection error");
        } catch (e) {
          setError("Connection error");
        }
      });

      eventSource.onerror = () => {
        setError("EventSource connection failed, falling back to polling");
        setIsConnected(false);
        eventSource.close();
        // Fall back to polling
        startPolling();
      };
    } else {
      // Use polling for Vercel (serverless doesn't support persistent SSE well)
      startPolling();
    }
    
    function startPolling() {
      setIsConnected(true);
      
      // Initial fetch
      fetchJobStatus(jobId).then(setStatus).catch(setError);
      
      // Poll every 2 seconds
      pollIntervalRef.current = setInterval(async () => {
        try {
          const jobStatus = await fetchJobStatus(jobId);
          setStatus(jobStatus);
          
          // Stop polling if job is complete
          if (jobStatus.status === "completed" || jobStatus.status === "failed") {
            if (pollIntervalRef.current) {
              clearInterval(pollIntervalRef.current);
            }
            setIsConnected(false);
          }
        } catch (e) {
          setError("Failed to fetch status");
        }
      }, 2000);
    }

    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current);
      }
    };
  }, [jobId]);

  return { status, isConnected, error };
}

// =============================================================================
// Components
// =============================================================================

const ProgressBar: React.FC<{ progress: number; status: string }> = ({
  progress,
  status,
}) => {
  const getStatusColor = () => {
    switch (status) {
      case "completed":
        return "bg-green-500";
      case "failed":
        return "bg-red-500";
      case "processing":
        return "bg-blue-500";
      default:
        return "bg-yellow-500";
    }
  };

  return (
    <div className="w-full">
      <div className="flex justify-between mb-1">
        <span className="text-sm font-medium text-gray-700">{status}</span>
        <span className="text-sm font-medium text-gray-700">{progress}%</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2.5">
        <div
          className={`h-2.5 rounded-full transition-all duration-300 ${getStatusColor()}`}
          style={{ width: `${Math.min(progress, 100)}%` }}
        />
      </div>
    </div>
  );
};

const ThumbnailCard: React.FC<{
  variant: ThumbnailVariant;
  onSelect?: () => void;
  isSelected?: boolean;
}> = ({ variant, onSelect, isSelected }) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);

  return (
    <div
      className={`relative rounded-lg overflow-hidden shadow-lg transition-all duration-200 ${
        isSelected
          ? "ring-4 ring-blue-500 scale-105"
          : "hover:shadow-xl hover:scale-102"
      }`}
    >
      <div className="aspect-video bg-gray-100 relative">
        {!imageLoaded && !imageError && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500" />
          </div>
        )}
        {imageError && (
          <div className="absolute inset-0 flex items-center justify-center text-red-500">
            Failed to load image
          </div>
        )}
        <img
          src={variant.image_url}
          alt={`Variant ${variant.variant_id}`}
          className={`w-full h-full object-cover transition-opacity duration-300 ${
            imageLoaded ? "opacity-100" : "opacity-0"
          }`}
          onLoad={() => setImageLoaded(true)}
          onError={() => setImageError(true)}
        />
      </div>
      <div className="p-3 bg-white">
        <p className="text-sm font-medium text-gray-900">
          {variant.variant_id}
        </p>
        {variant.metadata?.style && (
          <p className="text-xs text-gray-500 mt-1">
            Style: {variant.metadata.style}
          </p>
        )}
        <button
          onClick={onSelect}
          className={`mt-2 w-full px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            isSelected
              ? "bg-blue-600 text-white"
              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
          }`}
        >
          {isSelected ? "Selected" : "Select"}
        </button>
      </div>
    </div>
  );
};

const GenerationForm: React.FC<{
  onSubmit: (request: GenerationRequest) => void;
  isLoading: boolean;
}> = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState<GenerationRequest>({
    channel_id: "",
    video_title: "",
    video_description: "",
    reference_thumbnail_url: "",
    num_variants: 3,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label
          htmlFor="channel_id"
          className="block text-sm font-medium text-gray-700"
        >
          Channel ID
        </label>
        <input
          type="text"
          id="channel_id"
          value={formData.channel_id}
          onChange={(e) =>
            setFormData((prev) => ({ ...prev, channel_id: e.target.value }))
          }
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm px-3 py-2 border"
          placeholder="UC..."
          required
        />
      </div>

      <div>
        <label
          htmlFor="video_title"
          className="block text-sm font-medium text-gray-700"
        >
          Video Title
        </label>
        <input
          type="text"
          id="video_title"
          value={formData.video_title}
          onChange={(e) =>
            setFormData((prev) => ({ ...prev, video_title: e.target.value }))
          }
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm px-3 py-2 border"
          placeholder="Enter video title..."
          required
        />
      </div>

      <div>
        <label
          htmlFor="video_description"
          className="block text-sm font-medium text-gray-700"
        >
          Video Description (Optional)
        </label>
        <textarea
          id="video_description"
          value={formData.video_description}
          onChange={(e) =>
            setFormData((prev) => ({
              ...prev,
              video_description: e.target.value,
            }))
          }
          rows={3}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm px-3 py-2 border"
          placeholder="Enter video description for better context..."
        />
      </div>

      <div>
        <label
          htmlFor="reference_url"
          className="block text-sm font-medium text-gray-700"
        >
          Reference Thumbnail URL (Optional)
        </label>
        <input
          type="url"
          id="reference_url"
          value={formData.reference_thumbnail_url}
          onChange={(e) =>
            setFormData((prev) => ({
              ...prev,
              reference_thumbnail_url: e.target.value,
            }))
          }
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm px-3 py-2 border"
          placeholder="https://..."
        />
      </div>

      <div>
        <label
          htmlFor="num_variants"
          className="block text-sm font-medium text-gray-700"
        >
          Number of Variants
        </label>
        <select
          id="num_variants"
          value={formData.num_variants}
          onChange={(e) =>
            setFormData((prev) => ({
              ...prev,
              num_variants: parseInt(e.target.value),
            }))
          }
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm px-3 py-2 border"
        >
          <option value={1}>1</option>
          <option value={2}>2</option>
          <option value={3}>3</option>
          <option value={4}>4</option>
          <option value={5}>5</option>
        </select>
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLoading ? (
          <>
            <svg
              className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              />
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              />
            </svg>
            Generating...
          </>
        ) : (
          "Generate Thumbnails"
        )}
      </button>
    </form>
  );
};

// =============================================================================
// Main Dashboard Component
// =============================================================================

export default function Dashboard() {
  const [currentJobId, setCurrentJobId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedVariant, setSelectedVariant] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [regenerating, setRegenerating] = useState(false);

  const { status, isConnected, error: streamError } = useJobStatusStream(currentJobId);

  const handleSubmit = useCallback(async (request: GenerationRequest) => {
    setIsSubmitting(true);
    setSubmitError(null);
    setSelectedVariant(null);

    try {
      const response = await submitGenerationRequest(request);
      setCurrentJobId(response.job_id);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : "Failed to submit");
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  const handleRegenerate = useCallback(async () => {
    if (!currentJobId) return;

    setRegenerating(true);
    setSubmitError(null);
    setSelectedVariant(null);

    try {
      const response = await regenerateThumbnails(currentJobId);
      setCurrentJobId(response.job_id);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : "Failed to regenerate");
    } finally {
      setRegenerating(false);
    }
  }, [currentJobId]);

  const isComplete = status?.status === "completed";
  const isFailed = status?.status === "failed";
  const isProcessing = status?.status === "processing" || status?.status === "pending";

  return (
    <div className="min-h-screen bg-gray-50">
      <Head>
        <title>AI Thumbnail Rendering Farm</title>
        <meta name="description" content="AI-powered YouTube thumbnail generation" />
      </Head>

      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                AI Thumbnail Rendering Farm
              </h1>
              <p className="text-sm text-gray-500 mt-1">
                Zero prompt-engineering required
              </p>
            </div>
            <div className="flex items-center space-x-4">
              {isConnected && (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse" />
                  Live
                </span>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Form */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-medium text-gray-900 mb-4">
                Generate Thumbnails
              </h2>
              <GenerationForm onSubmit={handleSubmit} isLoading={isSubmitting} />
            </div>

            {/* Job Status Panel */}
            {currentJobId && (
              <div className="mt-6 bg-white rounded-lg shadow p-6">
                <h3 className="text-sm font-medium text-gray-900 mb-2">
                  Job Status
                </h3>
                <div className="space-y-3">
                  <div className="text-xs text-gray-500 font-mono break-all">
                    {currentJobId}
                  </div>
                  {status && (
                    <ProgressBar progress={status.progress} status={status.status} />
                  )}
                  {status?.message && (
                    <p className="text-sm text-gray-600">{status.message}</p>
                  )}
                  {isComplete && (
                    <button
                      onClick={handleRegenerate}
                      disabled={regenerating}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                    >
                      {regenerating ? "Queueing..." : "Regenerate (Priority)"}
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Errors */}
            {(submitError || streamError) && (
              <div className="mt-6 bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-sm text-red-600">
                  {submitError || streamError}
                </p>
              </div>
            )}
          </div>

          {/* Right Column - Results */}
          <div className="lg:col-span-2">
            {isProcessing && !status?.variants && (
              <div className="bg-white rounded-lg shadow p-12">
                <div className="flex flex-col items-center justify-center">
                  <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-500" />
                  <p className="mt-4 text-lg text-gray-600">
                    Generating your thumbnails...
                  </p>
                  <p className="mt-2 text-sm text-gray-500">
                    This may take 30-60 seconds
                  </p>
                </div>
              </div>
            )}

            {isFailed && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-8">
                <div className="flex flex-col items-center">
                  <svg
                    className="h-12 w-12 text-red-500"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  <h3 className="mt-4 text-lg font-medium text-red-900">
                    Generation Failed
                  </h3>
                  <p className="mt-2 text-sm text-red-600">
                    {status?.error || "An unknown error occurred"}
                  </p>
                  <button
                    onClick={handleRegenerate}
                    className="mt-4 px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
                  >
                    Try Again
                  </button>
                </div>
              </div>
            )}

            {isComplete && status?.variants && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-medium text-gray-900">
                    Generated Variants
                  </h2>
                  <span className="text-sm text-gray-500">
                    Select your preferred thumbnail
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {status.variants.map((variant) => (
                    <ThumbnailCard
                      key={variant.variant_id}
                      variant={variant}
                      onSelect={() => setSelectedVariant(variant.variant_id)}
                      isSelected={selectedVariant === variant.variant_id}
                    />
                  ))}
                </div>

                {selectedVariant && (
                  <div className="mt-6 bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-green-900">
                          Variant {selectedVariant} selected
                        </p>
                        <p className="text-xs text-green-700 mt-1">
                          This thumbnail is ready for upload
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          const variant = status.variants?.find(
                            (v) => v.variant_id === selectedVariant
                          );
                          if (variant) {
                            window.open(variant.image_url, "_blank");
                          }
                        }}
                        className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
                      >
                        Download
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {!currentJobId && (
              <div className="bg-white rounded-lg shadow p-12">
                <div className="flex flex-col items-center justify-center text-center">
                  <svg
                    className="h-16 w-16 text-gray-300"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1}
                      d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                    />
                  </svg>
                  <h3 className="mt-4 text-lg font-medium text-gray-900">
                    No Active Job
                  </h3>
                  <p className="mt-2 text-sm text-gray-500 max-w-sm">
                    Fill out the form to generate AI-powered thumbnails for your
                    YouTube video
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
