"""
================================================================================
Programmatic Compositing Engine - Python Pillow (PIL)
================================================================================
Deterministic text compositing and image overlay system for thumbnail generation.

Key Features:
- Dynamic text wrapping using getbbox() for multi-language support
- High-contrast drop shadows for readability
- Brand-safe logo placement avoiding YouTube timestamp area
- Deterministic output (no AI text generation)

YouTube Thumbnail Specifications:
- Resolution: 1280x720 pixels
- Safe Zone: Avoid bottom-right 200x150px (timestamp area)
- Title Area: Top-left quadrant with padding
================================================================================
"""

import io
import logging
import os
from typing import Optional, Tuple, List
from dataclasses import dataclass

import requests
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance

logger = logging.getLogger(__name__)

# =============================================================================
# Constants
# =============================================================================

# YouTube thumbnail dimensions
THUMBNAIL_WIDTH = 1280
THUMBNAIL_HEIGHT = 720

# Safe zones (avoid these areas)
TIMESTAMP_ZONE = (1080, 570, 1280, 720)  # Bottom-right corner for YouTube timestamp
LOGO_ZONE = (20, 570, 200, 700)  # Bottom-left for channel logo

# Title area (top-left quadrant with padding)
TITLE_AREA = {
    "x": 40,
    "y": 40,
    "width": 800,
    "height": 400,
}

# Font configuration
DEFAULT_FONT_SIZE = 72
MIN_FONT_SIZE = 36
MAX_FONT_SIZE = 96
LINE_SPACING = 1.2  # Multiplier for line height

# Shadow configuration
SHADOW_OFFSET = (4, 4)
SHADOW_BLUR = 4
SHADOW_OPACITY = 180

# Color palette
COLORS = {
    "white": (255, 255, 255),
    "black": (0, 0, 0),
    "shadow": (0, 0, 0, SHADOW_OPACITY),
    "text_stroke": (0, 0, 0, 200),
}

# Font paths (fallback chain)
FONT_PATHS = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
    "/System/Library/Fonts/Helvetica.ttc",  # macOS
    "C:/Windows/Fonts/arialbd.ttf",  # Windows
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]


@dataclass
class TextStyle:
    """Configuration for text rendering style."""
    font_size: int = DEFAULT_FONT_SIZE
    font_color: Tuple[int, int, int] = COLORS["white"]
    stroke_width: int = 3
    stroke_color: Tuple[int, int, int] = COLORS["black"]
    shadow_offset: Tuple[int, int] = SHADOW_OFFSET
    shadow_blur: int = SHADOW_BLUR
    line_spacing: float = LINE_SPACING
    max_width: int = TITLE_AREA["width"]


# =============================================================================
# Font Management
# =============================================================================

def get_available_font(size: int) -> ImageFont.FreeTypeFont:
    """
    Get an available font at the specified size.
    
    Tries multiple system font paths and falls back to default.
    
    Args:
        size: Font size in pixels
        
    Returns:
        PIL ImageFont object
    """
    for font_path in FONT_PATHS:
        if os.path.exists(font_path):
            try:
                return ImageFont.truetype(font_path, size)
            except Exception as e:
                logger.debug(f"Failed to load font {font_path}: {e}")
                continue
    
    # Fallback to default font
    logger.warning("Using default font, text rendering may be suboptimal")
    return ImageFont.load_default()


def calculate_font_size_for_text(
    text: str,
    max_width: int,
    max_height: int,
    max_lines: int = 3,
) -> int:
    """
    Calculate optimal font size to fit text within constraints.
    
    Args:
        text: Text to render
        max_width: Maximum width in pixels
        max_height: Maximum height in pixels
        max_lines: Maximum number of lines
        
    Returns:
        Optimal font size
    """
    # Start with max size and work down
    for size in range(MAX_FONT_SIZE, MIN_FONT_SIZE - 1, -4):
        font = get_available_font(size)
        lines = wrap_text(text, font, max_width)
        
        if len(lines) > max_lines:
            continue
        
        # Calculate total height
        line_height = size * LINE_SPACING
        total_height = len(lines) * line_height
        
        if total_height <= max_height:
            return size
    
    return MIN_FONT_SIZE


# =============================================================================
# Text Wrapping
# =============================================================================

def wrap_text(text: str, font: ImageFont.FreeTypeFont, max_width: int) -> List[str]:
    """
    Dynamically wrap text into multiple lines based on pixel width.
    
    Uses getbbox() for accurate text measurement across languages.
    Handles long translated strings (German, etc.) correctly.
    
    Args:
        text: Text to wrap
        font: PIL ImageFont for measurement
        max_width: Maximum line width in pixels
        
    Returns:
        List of wrapped lines
    """
    if not text:
        return []
    
    # Clean the text
    text = text.strip()
    
    # Try to fit on one line first
    bbox = font.getbbox(text)
    if bbox and bbox[2] <= max_width:
        return [text]
    
    # Need to wrap
    words = text.split()
    lines = []
    current_line = []
    
    for word in words:
        # Test adding this word
        test_line = " ".join(current_line + [word])
        bbox = font.getbbox(test_line)
        
        if bbox and bbox[2] <= max_width:
            # Word fits, add it
            current_line.append(word)
        else:
            # Word doesn't fit, start new line
            if current_line:
                lines.append(" ".join(current_line))
            current_line = [word]
            
            # Handle very long single words
            word_bbox = font.getbbox(word)
            if word_bbox and word_bbox[2] > max_width:
                # Word is too long, need to break it
                lines.extend(_break_long_word(word, font, max_width))
                current_line = []
    
    # Add remaining words
    if current_line:
        lines.append(" ".join(current_line))
    
    return lines if lines else [text]


def _break_long_word(word: str, font: ImageFont.FreeTypeFont, max_width: int) -> List[str]:
    """
    Break a very long word into segments that fit within max_width.
    
    Args:
        word: Long word to break
        font: PIL ImageFont
        max_width: Maximum width in pixels
        
    Returns:
        List of word segments
    """
    segments = []
    current_segment = ""
    
    for char in word:
        test_segment = current_segment + char
        bbox = font.getbbox(test_segment)
        
        if bbox and bbox[2] <= max_width:
            current_segment = test_segment
        else:
            if current_segment:
                segments.append(current_segment)
            current_segment = char
    
    if current_segment:
        segments.append(current_segment)
    
    return segments


# =============================================================================
# Text Rendering
# =============================================================================

def create_text_layer(
    text: str,
    style: TextStyle,
    image_size: Tuple[int, int],
) -> Image.Image:
    """
    Create a transparent layer with rendered text and effects.
    
    Args:
        text: Text to render
        style: TextStyle configuration
        image_size: Size of the output image
        
    Returns:
        RGBA image with text
    """
    # Create transparent layer
    layer = Image.new("RGBA", image_size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    
    # Get font
    font = get_available_font(style.font_size)
    
    # Wrap text
    lines = wrap_text(text, font, style.max_width)
    
    # Calculate starting position (top-left with padding)
    x = TITLE_AREA["x"]
    y = TITLE_AREA["y"]
    
    # Calculate line height
    bbox = font.getbbox("Ay")
    line_height = (bbox[3] - bbox[1]) * style.line_spacing if bbox else style.font_size * 1.2
    
    # Render each line with shadow and stroke
    for line in lines:
        # Create shadow
        shadow_layer = Image.new("RGBA", image_size, (0, 0, 0, 0))
        shadow_draw = ImageDraw.Draw(shadow_layer)
        
        shadow_x = x + style.shadow_offset[0]
        shadow_y = y + style.shadow_offset[1]
        
        # Draw shadow text
        shadow_draw.text(
            (shadow_x, shadow_y),
            line,
            font=font,
            fill=COLORS["shadow"],
        )
        
        # Blur shadow
        if style.shadow_blur > 0:
            shadow_layer = shadow_layer.filter(
                ImageFilter.GaussianBlur(radius=style.shadow_blur)
            )
        
        # Composite shadow
        layer = Image.alpha_composite(layer, shadow_layer)
        draw = ImageDraw.Draw(layer)
        
        # Draw stroke (outline)
        if style.stroke_width > 0:
            for dx in range(-style.stroke_width, style.stroke_width + 1):
                for dy in range(-style.stroke_width, style.stroke_width + 1):
                    if dx != 0 or dy != 0:
                        draw.text(
                            (x + dx, y + dy),
                            line,
                            font=font,
                            fill=style.stroke_color,
                        )
        
        # Draw main text
        draw.text(
            (x, y),
            line,
            font=font,
            fill=style.font_color,
        )
        
        # Move to next line
        y += line_height
    
    return layer


# =============================================================================
# Logo Handling
# =============================================================================

def download_logo(logo_url: str, timeout: int = 3) -> Optional[Image.Image]:
    """
    Download and prepare a channel logo.
    
    Args:
        logo_url: URL of the logo image
        timeout: Download timeout in seconds
        
    Returns:
        PIL Image or None if download failed
    """
    try:
        response = requests.get(logo_url, timeout=timeout)
        response.raise_for_status()
        
        img = Image.open(io.BytesIO(response.content))
        
        # Convert to RGBA if needed
        if img.mode != "RGBA":
            img = img.convert("RGBA")
        
        # Resize to appropriate size (max 150x150)
        max_size = (150, 150)
        img.thumbnail(max_size, Image.Resampling.LANCZOS)
        
        return img
        
    except Exception as e:
        logger.warning(f"Failed to download logo from {logo_url}: {e}")
        return None


def add_logo_to_image(
    image: Image.Image,
    logo: Image.Image,
    position: str = "bottom-left",
) -> Image.Image:
    """
    Add a logo to the image at the specified position.
    
    Args:
        image: Base image
        logo: Logo image (RGBA)
        position: "bottom-left" or "bottom-right"
        
    Returns:
        Image with logo composited
    """
    img_width, img_height = image.size
    logo_width, logo_height = logo.size
    
    # Calculate position (avoiding timestamp area)
    if position == "bottom-left":
        x = 20
        y = img_height - logo_height - 20
    elif position == "bottom-right":
        # Keep away from timestamp area
        x = img_width - logo_width - 220  # 220px from right edge
        y = img_height - logo_height - 20
    else:
        x = 20
        y = img_height - logo_height - 20
    
    # Create a copy and paste logo
    result = image.copy()
    result.paste(logo, (x, y), logo)
    
    return result


# =============================================================================
# Main Compositing Function
# =============================================================================

async def composite_thumbnail(
    background_bytes: bytes,
    title: str,
    channel_logo_url: Optional[str] = None,
    variant_index: int = 0,
) -> bytes:
    """
    Composite a complete thumbnail from background, title, and optional logo.
    
    Args:
        background_bytes: Raw background image bytes
        title: Video title text
        channel_logo_url: Optional URL for channel logo
        variant_index: Index for style variation
        
    Returns:
        Raw PNG bytes of composited thumbnail
    """
    # Load background image
    background = Image.open(io.BytesIO(background_bytes))
    
    # Ensure correct size
    if background.size != (THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT):
        background = background.resize(
            (THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT),
            Image.Resampling.LANCZOS,
        )
    
    # Convert to RGBA
    if background.mode != "RGBA":
        background = background.convert("RGBA")
    
    # Calculate optimal font size based on title length
    font_size = calculate_font_size_for_text(
        text=title,
        max_width=TITLE_AREA["width"],
        max_height=TITLE_AREA["height"],
        max_lines=3,
    )
    
    # Vary style based on variant index
    styles = [
        TextStyle(font_size=font_size, font_color=COLORS["white"]),
        TextStyle(font_size=font_size, font_color=(255, 255, 200)),  # Warm white
        TextStyle(font_size=font_size, font_color=(200, 255, 255)),  # Cool white
    ]
    style = styles[variant_index % len(styles)]
    
    # Create text layer
    text_layer = create_text_layer(title, style, background.size)
    
    # Composite text onto background
    result = Image.alpha_composite(background, text_layer)
    
    # Add logo if provided
    if channel_logo_url:
        logo = download_logo(channel_logo_url, timeout=3)
        if logo:
            result = add_logo_to_image(result, logo, position="bottom-left")
    
    # Convert to RGB for final output (JPEG doesn't support alpha)
    if result.mode == "RGBA":
        # Create white background
        rgb_result = Image.new("RGB", result.size, (255, 255, 255))
        rgb_result.paste(result, mask=result.split()[3])  # Use alpha as mask
        result = rgb_result
    
    # Save to bytes
    output = io.BytesIO()
    result.save(output, format="PNG", optimize=True)
    output.seek(0)
    
    logger.info(f"Composited thumbnail: {len(output.getvalue())} bytes")
    return output.getvalue()


# =============================================================================
# Prompt Generation
# =============================================================================

def create_variant_prompts(
    video_title: str,
    video_description: Optional[str] = None,
    num_variants: int = 3,
) -> List[str]:
    """
    Create AI image generation prompts for each variant.
    
    Args:
        video_title: Video title for context
        video_description: Optional description for more context
        num_variants: Number of variants to generate
        
    Returns:
        List of prompts for each variant
    """
    base_context = video_description or video_title
    
    prompts = [
        f"Professional YouTube thumbnail background, {base_context}, "
        f"clean modern design, high contrast, vibrant colors, "
        f"tech tutorial style, 16:9 aspect ratio, photorealistic",
        
        f"YouTube thumbnail background, {base_context}, "
        f"digital art style, gradient background, "
        f"professional software tutorial aesthetic, cinematic lighting",
        
        f"Eye-catching YouTube thumbnail background, {base_context}, "
        f"bold colors, modern tech aesthetic, "
        f"software development theme, high quality render",
    ]
    
    # Return requested number of variants
    return prompts[:num_variants]


# =============================================================================
# Utility Functions
# =============================================================================

def create_placeholder_thumbnail(
    width: int = THUMBNAIL_WIDTH,
    height: int = THUMBNAIL_HEIGHT,
    text: str = "Thumbnail",
) -> bytes:
    """
    Create a placeholder thumbnail for testing.
    
    Args:
        width: Image width
        height: Image height
        text: Text to display
        
    Returns:
        Raw PNG bytes
    """
    # Create gradient background
    img = Image.new("RGB", (width, height))
    draw = ImageDraw.Draw(img)
    
    # Draw simple gradient
    for y in range(height):
        r = int(50 + (y / height) * 100)
        g = int(100 + (y / height) * 50)
        b = int(150 + (y / height) * 50)
        draw.line([(0, y), (width, y)], fill=(r, g, b))
    
    # Add text
    font = get_available_font(64)
    
    # Calculate text position (centered)
    bbox = font.getbbox(text)
    if bbox:
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        x = (width - text_width) // 2
        y = (height - text_height) // 2
    else:
        x, y = width // 4, height // 2
    
    # Draw shadow
    draw.text((x + 3, y + 3), text, font=font, fill=(0, 0, 0))
    draw.text((x, y), text, font=font, fill=(255, 255, 255))
    
    # Save
    output = io.BytesIO()
    img.save(output, format="PNG")
    output.seek(0)
    
    return output.getvalue()
