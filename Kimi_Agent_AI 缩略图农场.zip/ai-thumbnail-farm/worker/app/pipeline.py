"""
================================================================================
Thumbnail Generation Pipeline
================================================================================
Orchestrates the end-to-end thumbnail generation process:
1. Parse job data
2. Generate AI background (with retry)
3. Download reference image (with timeout)
4. Composite text and logo
5. Upload to storage
6. Update database

This is the main entry point for RQ workers.
================================================================================
"""

import asyncio
import logging
import os
from datetime import datetime
from typing import Any

import asyncpg
from redis import Redis

from app.ai_generation import generate_ai_background, download_reference_image
from app.compositor import composite_thumbnail, create_variant_prompts
from app.retry import async_retry_with_backoff
from app.services.database import DatabaseService
from app.services.storage import StorageService, LocalStorageService

logger = logging.getLogger(__name__)

# Configuration
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/thumbnail_farm")
USE_LOCAL_STORAGE = os.getenv("USE_LOCAL_STORAGE", "false").lower() == "true"


async def process_thumbnail_job(job_data: dict[str, Any]) -> dict[str, Any]:
    """
    Process a thumbnail generation job through the complete pipeline.
    
    This is the main entry point called by RQ workers.
    
    Pipeline stages:
    1. Parse and validate job data
    2. Generate AI backgrounds (parallel for variants)
    3. Download reference image (with timeout)
    4. Composite each variant with text and logo
    5. Upload to storage
    6. Update database with results
    
    Args:
        job_data: Dictionary containing job parameters
        
    Returns:
        Dictionary with job results and variant URLs
    """
    job_id = job_data["job_id"]
    channel_id = job_data["channel_id"]
    video_title = job_data["video_title"]
    video_description = job_data.get("video_description", "")
    reference_url = job_data.get("reference_thumbnail_url")
    num_variants = job_data.get("num_variants", 3)
    
    logger.info(f"Starting thumbnail generation pipeline for job {job_id}")
    
    # Initialize services
    db = DatabaseService(DATABASE_URL)
    await db.connect()
    
    if USE_LOCAL_STORAGE:
        storage = LocalStorageService()
    else:
        storage = StorageService()
    
    try:
        # Update status to processing
        await db.update_job_status(
            job_id=job_id,
            status="processing",
            progress=10,
            message="Generating AI backgrounds...",
        )
        
        # Generate prompts for each variant
        prompts = create_variant_prompts(
            video_title=video_title,
            video_description=video_description,
            num_variants=num_variants,
        )
        
        # Download reference image (with 3-second timeout)
        reference_image = None
        if reference_url:
            logger.info(f"Downloading reference image from {reference_url}")
            reference_image = await download_reference_image(reference_url, timeout=3)
            if reference_image:
                logger.info("Reference image downloaded successfully")
            else:
                logger.warning("Failed to download reference image, continuing without it")
        
        # Update progress
        await db.update_job_status(
            job_id=job_id,
            status="processing",
            progress=30,
            message="Generating AI backgrounds...",
        )
        
        # Generate AI backgrounds in parallel
        background_tasks = [
            generate_ai_background(
                prompt=prompt,
                width=1280,
                height=720,
                style="photorealistic" if i == 0 else "digital-art" if i == 1 else "cinematic",
            )
            for i, prompt in enumerate(prompts)
        ]
        
        backgrounds = await asyncio.gather(*background_tasks, return_exceptions=True)
        
        # Check for failures
        successful_backgrounds = []
        for i, bg in enumerate(backgrounds):
            if isinstance(bg, Exception):
                logger.error(f"Background {i+1} generation failed: {bg}")
            else:
                successful_backgrounds.append(bg)
        
        if not successful_backgrounds:
            raise RuntimeError("All background generations failed")
        
        # Update progress
        await db.update_job_status(
            job_id=job_id,
            status="processing",
            progress=60,
            message="Compositing thumbnails...",
        )
        
        # Composite each variant
        variants = []
        for i, background in enumerate(successful_backgrounds[:num_variants]):
            variant_id = f"variant-{i+1}"
            
            try:
                # Composite thumbnail
                composited = await composite_thumbnail(
                    background_bytes=background,
                    title=video_title,
                    channel_logo_url=None,  # Could be fetched from channel data
                    variant_index=i,
                )
                
                # Generate storage key
                storage_key = storage.generate_thumbnail_key(
                    job_id=job_id,
                    variant_id=variant_id,
                    extension="png",
                )
                
                # Upload to storage
                image_url = await storage.upload_image(
                    image_data=composited,
                    key=storage_key,
                    content_type="image/png",
                    metadata={
                        "job_id": job_id,
                        "variant_id": variant_id,
                        "channel_id": channel_id,
                        "video_title": video_title,
                    },
                )
                
                variants.append({
                    "variant_id": variant_id,
                    "image_url": image_url,
                    "storage_key": storage_key,
                    "metadata": {
                        "prompt": prompts[i],
                        "style": "photorealistic" if i == 0 else "digital-art" if i == 1 else "cinematic",
                    },
                })
                
                logger.info(f"Variant {variant_id} completed: {image_url}")
                
            except Exception as e:
                logger.error(f"Failed to composite variant {variant_id}: {e}")
        
        if not variants:
            raise RuntimeError("All variant compositing failed")
        
        # Update database with results
        await db.update_job_variants(job_id, variants)
        
        logger.info(f"Job {job_id} completed with {len(variants)} variants")
        
        return {
            "job_id": job_id,
            "status": "completed",
            "variants": variants,
            "completed_at": datetime.utcnow().isoformat(),
        }
        
    except Exception as e:
        logger.exception(f"Job {job_id} failed: {e}")
        
        # Update database with error
        await db.update_job_status(
            job_id=job_id,
            status="failed",
            progress=0,
            message="Job failed",
            error=str(e),
        )
        
        raise
        
    finally:
        await db.disconnect()


def process_thumbnail_job_sync(job_data: dict[str, Any]) -> dict[str, Any]:
    """
    Synchronous wrapper for process_thumbnail_job for RQ compatibility.
    
    RQ workers call functions synchronously, so we need this wrapper
    to run the async pipeline.
    
    Args:
        job_data: Dictionary containing job parameters
        
    Returns:
        Dictionary with job results
    """
    return asyncio.run(process_thumbnail_job(job_data))
